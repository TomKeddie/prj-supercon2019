Machinechat JEDI One is a ready-to-use IoT data management software solution.

Default username: admin
Default password: admin

For information and support on how to use this software, go to:
https://support.machinechat.io

Contact:
Machinechat LLC
https://machinechat.io
Support e-mail: support@machinechat.io
Twitter: @Machinechat
Software credits: https://www.machinechat.io/software-credits
